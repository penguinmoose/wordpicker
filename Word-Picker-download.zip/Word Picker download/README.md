# Word Picker

Word Picker is a tool for finding words based on a spelling pattern or a sound. The easy to use interface enables you to
find results without any trouble. There is also a sentence picker, so you can also find sentences that contain a
word. There are lots of results so you find just what you need. A instructions tab is even avalible so you can know exactly
how to use it. There is a Word Picker shortcut you can add on an iPad or an iPhone so you do not need to use Word Picker on
the web.

[Go to Word Picker](http://www.johanneschan.com/wordpicker/wordpicker.html)
